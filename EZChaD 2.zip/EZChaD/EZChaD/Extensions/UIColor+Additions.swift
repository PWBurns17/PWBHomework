//
//  UIColor+Additions.swift
//  EZChaD
//
//  Created by Field Employee on 04/09/2021.
//

import UIKit

extension UIColor {
  static var primary: UIColor {
    // swiftlint:disable:next force_unwrapping
    return UIColor(named: "rw-green")!
  }

  static var incomingMessage: UIColor {
    // swiftlint:disable:next force_unwrapping
    return UIColor(named: "incoming-message")!
  }
}
