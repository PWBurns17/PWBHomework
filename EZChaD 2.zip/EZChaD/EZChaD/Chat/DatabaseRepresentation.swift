//
//  DatabaseRepresentation.swift
//  EZChaD
//
//  Created by Field Employee on 04/09/2021.
//

import Foundation

protocol DatabaseRepresentation {
  var representation: [String: Any] { get }
}
