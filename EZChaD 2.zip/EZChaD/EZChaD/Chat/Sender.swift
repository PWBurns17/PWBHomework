//
//  Sender.swift
//  EZChaD
//
//  Created by Field Employee on 04/09/2021.
//

import Foundation
import MessageKit

struct Sender: SenderType {
  let senderId: String
  let displayName: String
}
