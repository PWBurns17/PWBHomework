//
//  PagedModeratorResponse.swift
//  Week5Homework
//
//  Created by Field Employee on 12/09/2021.
//

import Foundation

struct PagedModeratorResponse: Decodable {
    
//    init(from decoder: Decoder) throws
//    {
//
//        return
//    }
    
  let stories: [Story]
  let total: Int
  let hasMore: Bool
  let page: Int
  
  enum CodingKeys: String, CodingKey {
    case stories = "items"
    case hasMore = "has_more"
    case total
    case page
  }
}
