//
//  ColorPallette.swift
//  Week5HomeworkInfiniteScroll
//
//  Created by Field Employee on 12/09/2021.
//

import Foundation
import UIKit

struct ColorPalette {
  static let RWGreen = UIColor(red: CGFloat(0), green: CGFloat(104/255.0), blue: CGFloat(55/255.0), alpha: CGFloat(1.0))
}
