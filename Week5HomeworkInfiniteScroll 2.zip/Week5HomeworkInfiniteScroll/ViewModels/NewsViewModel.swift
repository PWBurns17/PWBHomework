//
//  NewsViewModel.swift
//  Week5Homework
//
//  Created by Field Employee on 11/09/2021.
//

import Foundation
import Combine

protocol NewsViewModelType {
    var count: Int { get }
    var storiesBinding: PassthroughSubject<Void, Never> { get }
    var errorBinding: Published<String>.Publisher { get }
    var updateRowBinding: Published<Int>.Publisher { get }
    func fetchStories()
    func getTitle(at row: Int) -> String
    func getScore(at row: Int) -> String
    func getNumComments(at row: Int) -> String
    //func getImage(at row: Int) -> Data?
}

class NewsViewModel: NewsViewModelType {
    // communication = closure, delegate/protocol, observer
    
    // MARK:- internal properties
    let storiesBinding = PassthroughSubject<Void, Never>()
    var errorBinding: Published<String>.Publisher { $messageError }
    var updateRowBinding: Published<Int>.Publisher { $updateRow }
    
    @Published private var updateRow = 0
    @Published private var messageError = ""
    
    var count: Int { stories.count }
    func getTitle(at row: Int) -> String { stories[row].title }
    func getScore(at row: Int) -> String { String(stories[row].score) }
    func getNumComments(at row: Int) -> String { String(stories[row].numComments) }
    
    // MARK:- private properties
    private var stories = [Story]()
    private let networkManager = NetworkManager()
    private var subscribers = Set<AnyCancellable>()
    private var imagesCache = [String: Data]()
    
    // MARK:- internal properties
    func fetchStories() {
        // create the url
        print("NewsViewModel.fetchStories")
        let urlS = "https://www.reddit.com/.json"
        
        networkManager
            .getStories(from: urlS)
            .sink { [weak self] completion in
                switch completion {
                case .finished:
                    break
                case .failure(let error):
                    self?.messageError = error.localizedDescription
                }
            } receiveValue: { [weak self] stories in
                self?.stories = stories
                self?.storiesBinding.send()
            }
            .store(in: &subscribers)
    }
    
//    func getImage(at row: Int) -> Data? {
//
//        let story = stories[row]
//        let imageUrl = story.imageUrl
//
//        if let data = imagesCache[imageUrl] {
//            return data
//        }
//
//        let urlS = imageUrl
//        networkManager
//            .getImageData(from: urlS)
//            .sink { _ in }
//                receiveValue: { [weak self] data in
//                    self?.imagesCache[imageUrl] = data
//                    self?.updateRow = row
//            }
//            .store(in: &subscribers)
//
//        return nil
//    }
}
