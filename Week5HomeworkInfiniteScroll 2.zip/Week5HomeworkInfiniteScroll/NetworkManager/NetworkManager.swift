//
//  NetworkManager.swift
//  Week5HomeworkInfiniteScroll
//
//  Created by Field Employee on 13/09/2021.
//

import Foundation
import Combine

class NetworkManager {
    
    private let session = URLSession.shared
    private let decoder = JSONDecoder()
    
    func getStories(from urlS: String) -> AnyPublisher<[Story], NetworkError> {
        
        guard let url = URL(string: urlS) else {
            return Fail(error: .url).eraseToAnyPublisher()
        }
        
        return session
            .dataTaskPublisher(for: url)
            .map { $0.0 }
            .decode(type: StoriesResponse.self, decoder: decoder)
            .mapError({ error -> NetworkError in
                print(error.localizedDescription)
                return NetworkError.other(error)
            })
            .map { $0.data.children.map { $0.story }
            //response in
//                let stories = response.data1.children.map { children in
//                    return children.story
//                }
//                return stories
            }
            .mapError({ _ in
                print("")
                return NetworkError.serverError
            })
            .eraseToAnyPublisher()
        
    }
    
    func getImageData(from urlS: String) -> AnyPublisher<Data, NetworkError> {
        
        guard let url = URL(string: urlS) else {
            return Fail(error: .url).eraseToAnyPublisher()
        }
        
        return session
            .dataTaskPublisher(for: url)
            .map { $0.data }
            .mapError({ _ in
                return NetworkError.serverError
            })
            .eraseToAnyPublisher()
    }
}
