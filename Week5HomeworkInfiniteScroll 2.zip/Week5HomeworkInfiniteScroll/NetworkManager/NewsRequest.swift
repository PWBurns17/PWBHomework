//
//  NewsRequest.swift
//  Week5Homework
//
//  Created by Field Employee on 12/09/2021.
//

import Foundation

struct NewsRequest {
  var path: String {
    return "users/moderators"
  }
  
  //let parameters: Parameters
  private init() {
    //self.parameters = parameters
  }
}

extension NewsRequest {
  static func from() -> NewsRequest {
    //let defaultParameters = ["order": "desc", "sort": "reputation", "filter": "!-*jbN0CeyJHb"]
    //let parameters = ["site": ""] //["site": "\(site)"].merging(defaultParameters, uniquingKeysWith: +)
    return NewsRequest() //parameters: parameters)
  }
}
