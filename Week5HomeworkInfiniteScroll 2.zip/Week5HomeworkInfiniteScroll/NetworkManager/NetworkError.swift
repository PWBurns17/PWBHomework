//
//  NetworkError.swift
//  Week5HomeworkInfiniteScroll
//
//  Created by Field Employee on 13/09/2021.
//

import Foundation

enum NetworkError: Error {
    case url
    case other(Error)
    case serverError
}
