//
//  StackExchangeClient.swift
//  Week5Homework
//
//  Created by Field Employee on 12/09/2021.
//

import Foundation

final class RedditClient {
  private lazy var baseURL: URL = {
    return URL(string: "http://www.reddit.com/.json")!
  }()
  
  let session: URLSession
  
  init(session: URLSession = URLSession.shared) {
    self.session = session
  }
  
  func fetchStories(with request: NewsRequest, page: Int, completion: @escaping (Result<PagedModeratorResponse, DataResponseError>) -> Void) {
    
  }
}
