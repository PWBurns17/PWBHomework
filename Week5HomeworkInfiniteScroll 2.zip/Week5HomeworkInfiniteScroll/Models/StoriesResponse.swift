//
//  StoriesResponse.swift
//  Week5HomeworkInfiniteScroll
//
//  Created by Field Employee on 13/09/2021.
//

import Foundation
import UIKit

struct StoriesResponse: Decodable {
    
//    var title: String = ""
//    var score: Int = 0
//    var numComments: Int = 0
//    let width: Int
//    let height: Int
//    let imageUrl: String
    var data: Data1
//    var children: [Children] //Array<Story>
//    var data2: [Data2]
    
//    enum StoriesCodingKeys: String, CodingKey {
//        case data1 = "data"
//        case children
//    }
//
//    enum Data1CodingKeys: String, CodingKey {
//        case children
//        case data1 = "data"
//    }
//
//    enum ChildrenCodingKeys: String, CodingKey {
//        case data1 = "data"
//        case title
//        case score
//        case numComments = "num_comments"
//    }
//
//    enum Data2CodingKeys: String, CodingKey {
//        case title
//        case score
//        case numComments = "num_comments"
//    }
    
//    init(from decoder: Decoder) throws {
//
//        if let storiesResponseContainer = try? decoder.container(keyedBy: StoriesCodingKeys.self){
//
//            if let data1Container = try? storiesResponseContainer.nestedContainer(keyedBy: StoriesCodingKeys.self, forKey: .data1){
//
//                if let childrenContainer = try? data1Container.nestedContainer(keyedBy: Data1CodingKeys.self, forKey: .children){
//
//
//
//                    if let data2Container = try? childrenContainer.nestedContainer(keyedBy: ChildrenCodingKeys.self, forKey: .data1){
//
//                        self.title = try data2Container.decode(String.self, forKey: .title)
//                        self.score = try data2Container.decode(Int.self, forKey: .score)
//                        self.numComments = try data2Container.decode(Int.self, forKey: .numComments)
//
////                        data1.append(data1Container)
////                        children.append(childrenContainer)
////                        data2.append(data2Container)
//                    }
//                }
//            }
//        }
//    }
}

struct Data1: Decodable
{
    var children: [Children]
}

struct Children: Decodable
{
    //var data2: [Data2]
    var story: Story
  
  enum ChildrenCodingKeys: String, CodingKey
  {
    //case data2 = "data"
    case story = "data"
  }
}

struct Data2: Decodable
{
    var title: String
    var score: Int
    var numComments: Int
  
  enum Data2CodingKeys: String, CodingKey
  {
    case title, score
    case numComments = "num_comments"
  }
}
