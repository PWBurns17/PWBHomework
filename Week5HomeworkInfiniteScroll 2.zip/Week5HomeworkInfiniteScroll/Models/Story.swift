//
//  Story.swift
//  Week5Homework
//
//  Created by Field Employee on 11/09/2021.
//

import Foundation

struct Story: Decodable
{
    let title: String
    let score: Int
    let numComments: Int
    //let width: Int
    //let height: Int
    //let imageUrl: String
  
  enum CodingKeys: String, CodingKey
  {
    case numComments = "num_comments"
    //case imageUrl = "thumbnail"
    case title, score //, width, height, response, data, children, preview, images, source
  }

  
//    init(title: String, score: Int, numComments: Int, width: Int, height: Int, imageUrl: String)
//    {
//        self.title = title
//        self.score = score
//        self.numComments = numComments
//        self.width = width
//        self.height = height
//        self.imageUrl = imageUrl
//  }
//
//  init(from decoder: Decoder) throws
//  {
//    let container = try decoder.container(keyedBy: CodingKeys.self)
//    let response = try container.nestedContainer(keyedBy: CodingKeys.self, forKey: .response)
//    let data = try response.nestedContainer(keyedBy: CodingKeys.self, forKey: .data)
//    let children = try data.nestedContainer(keyedBy: CodingKeys.self, forKey: .children)
//    let data2 = try children.nestedContainer(keyedBy: CodingKeys.self, forKey: .data)
//    let title = try data2.decode(String.self, forKey: .title)
//    let score = try data2.decode(Int.self, forKey: .score)
//    let numComments = try data2.decode(Int.self, forKey: .numComments)
//    let preview = try data2.nestedContainer(keyedBy: CodingKeys.self, forKey: .preview)
//    let images = try preview.nestedContainer(keyedBy: CodingKeys.self, forKey: .images)
//    let source = try images.nestedContainer(keyedBy: CodingKeys.self, forKey: .source)
//    let imageUrl = try source.decode(String.self, forKey: .imageUrl)
//    let width = try source.decode(Int.self, forKey: .width)
//    let height = try source.decode(Int.self, forKey: .height)
//    self.init(title: title, score: score, numComments: numComments, width: width, height: height, imageUrl: imageUrl)
//  }
}
