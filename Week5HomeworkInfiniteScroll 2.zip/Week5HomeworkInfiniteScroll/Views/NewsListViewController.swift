//
//  NewsListViewController.swift
//  Week5Homework
//
//  Created by Field Employee on 11/09/2021.
//

import UIKit
import Combine

class NewsListViewController: UIViewController, AlertDisplayer {
  
  //@IBOutlet var indicatorView: UIActivityIndicatorView!
  //@IBOutlet var tableView: UITableView!
    var indicatorView = UIActivityIndicatorView()
    var tableView = UITableView()
    var safeArea: UILayoutGuide!
  
  var site: String!
  
  private var viewModel: NewsViewModelType = NewsViewModel()
    private var subscribers = Set<AnyCancellable>()
  
  private var shouldShowLoadingCell = false
    
    override func loadView()
    {
        super.loadView()
        
        view.backgroundColor = .white
            safeArea = view.layoutMarginsGuide
        
        view.addSubview(tableView)
        
        tableView.translatesAutoresizingMaskIntoConstraints = false
            tableView.topAnchor.constraint(equalTo: safeArea.topAnchor).isActive = true
            tableView.leftAnchor.constraint(equalTo: view.leftAnchor).isActive = true
            tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor).isActive = true
            tableView.rightAnchor.constraint(equalTo: view.rightAnchor).isActive = true
    
    //indicatorView.color = ColorPalette.RWGreen
    //indicatorView.startAnimating()
    
    //tableView.isHidden = true
    //tableView.separatorColor = ColorPalette.RWGreen
    tableView.dataSource = self
    
    //let request = NewsRequest.from()
    //viewModel = NewsViewModel(request: request, delegate: self)
        tableView.delegate = self
        tableView.dataSource = self
        
        setUpBinding()
        
  }
    
//    override func viewDidAppear(_ animated: Bool) {
//        super.viewDidAppear(animated)
//    }
    
    private func setUpBinding() {
        
        // create binding of movies
        viewModel
            .storiesBinding
            .receive(on: RunLoop.main)
            .sink
            { [weak self] in
                self?.tableView.reloadData()
            }
            .store(in: &subscribers)
        
        // create binding for errors
        viewModel
            .errorBinding
            .dropFirst()
            .receive(on: RunLoop.main)
            .sink
            { [weak self] messageError in
                self?.displayErrorAlert(messageError)
            }
            .store(in: &subscribers)
        
        // binding to update row
        viewModel
            .updateRowBinding
            .dropFirst()
            .receive(on: RunLoop.main)
            .sink
            { [weak self] row in
                self?.tableView.reloadRows(at: [IndexPath(row: row, section: 0)], with: .automatic)
            }
            .store(in: &subscribers)
        
        viewModel.fetchStories()
    }
    
    private func displayErrorAlert(_ errorMessage: String)
    {
        let alert = UIAlertController(title: "Error", message: errorMessage, preferredStyle: .alert)
        let acceptAction = UIAlertAction(title: "Accept", style: .default)
        alert.addAction(acceptAction)
        present(alert, animated: true)
    }
}

extension NewsListViewController: UITableViewDataSource
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        print("NewsListViewController.numberOfRowsInSection viewModel.count: \(viewModel.count)")
        return viewModel.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        print("NewsListViewController.cellForRowAt")
        guard let cell = tableView.dequeueReusableCell(withIdentifier: NewsTableViewCell.identifier, for: indexPath) as? NewsTableViewCell
        else { return UITableViewCell() }
        
        let row = indexPath.row
        let title = viewModel.getTitle(at: row)
        let score = viewModel.getScore(at: row)
        let numComments = viewModel.getNumComments(at: row)
        //let data = viewModel.getImage(at: row)
        cell.configureCell(title: title, score: score, numComments: numComments) //, imageData: data)
        
        return cell
    }
}

extension NewsListViewController: UITableViewDelegate
{
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        let newsCell = NewsTableViewCell()

        return newsCell.getHeight(text: viewModel.getTitle(at: indexPath.row), font: UIFont.systemFont(ofSize: 17) , width: 281.5) + 150

    }
}
