//
//  NewsTableViewCell.swift
//  Week5Homework
//
//  Created by Field Employee on 12/09/2021.
//

import UIKit

class NewsTableViewCell: UITableViewCell {

    var indicatorView: UIActivityIndicatorView!
    static let identifier = "NewsTableViewCell"
    
    let titleLabel:UILabel = {
        let label = UILabel()
        label.font = UIFont.boldSystemFont(ofSize: 20)
        //label.textColor =  colorLiteral(red: 0.2549019754, green: 0.2745098174, blue: 0.3019607961, alpha: 1)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    let scoreLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.boldSystemFont(ofSize: 20)
        //label.textColor =  colorLiteral(red: 0.2549019754, green: 0.2745098174, blue: 0.3019607961, alpha: 1)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
        
    }()
    let numCommentsLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.boldSystemFont(ofSize: 20)
        //label.textColor =  colorLiteral(red: 0.2549019754, green:
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        
            super.init(style: style, reuseIdentifier: reuseIdentifier)

//            imgUser.layer.cornerRadius = imgUser.frame.size.width / 2;
//            imgUser.clipsToBounds = true;

        titleLabel.text = "titleLabel"

        self.contentView.addSubview(titleLabel)
        self.contentView.addSubview(scoreLabel)
        self.contentView.addSubview(numCommentsLabel)

//         productImage.anchor(top: topAnchor, left: leftAnchor, bottom: bottomAnchor, right: nil, paddingTop: 5, paddingLeft: 5, paddingBottom: 5, paddingRight: 0, width: 90, height: 0, enableInsets: false)
//        titleLabel.anchor(top: topAnchor, left: leftAnchor, bottom: nil, right: nil, paddingTop: 20, paddingLeft: 10, paddingBottom: 0, paddingRight: 0, width: frame.size.width / 2, height: 0, enableInsets: false)
//        scoreLabel.anchor(top: productNameLabel.bottomAnchor, left: leftAnchor, bottom: nil, right: nil, paddingTop: 0, paddingLeft: 10, paddingBottom: 0, paddingRight: 0, width: frame.size.width / 2, height: 0, enableInsets: false)
//        numCommentsLabel.anchor(top: scoreLabel.bottomAnchor, left: leftAnchor, bottom: nil, right: nil, paddingTop: 0, paddingLeft: 10, paddingBottom: 0, paddingRight: 0, width: frame.size.width / 2, height: 0, enableInsets: false)
        }
    
    required init(coder aDecoder: NSCoder) {
             fatalError("init(coder:) has not been implemented")
        }
  
  override func prepareForReuse() {
    super.prepareForReuse()
    
    configureCell(title: "", score: "0", numComments: "0") //, imageData: .none)
  }
  
  override func awakeFromNib() {
    super.awakeFromNib()
    
    //reputationContainerView.backgroundColor = .lightGray
    //reputationContainerView.layer.cornerRadius = 6
    
    indicatorView.hidesWhenStopped = true
    indicatorView.color = ColorPalette.RWGreen
  }
  
    func configureCell(title: String?, score: String?, numComments: String?) { //}, imageData: Data?) {
        print("NewsTableViewCell.confirgureCell")
        //movieOverviewLabel.sizeToFit()
        titleLabel.text = title
        scoreLabel.text = String(score!)
        numCommentsLabel.text = String(numComments!)
        //movieImageView.image = nil
        //if let data = imageData {
        // movieImageView.image = UIImage(data: data)
        }
    
    func getHeight(text:String?, font:UIFont, width:CGFloat) -> CGFloat {
        let myLabel:UILabel = UILabel(frame: CGRect(x: 103, y: 33, width: width, height: CGFloat.greatestFiniteMagnitude))
        myLabel.numberOfLines = 0
        myLabel.lineBreakMode = NSLineBreakMode.byWordWrapping
        myLabel.font = font
        myLabel.text = text

        myLabel.sizeToFit()
        return myLabel.bounds.size.height
    }
}
